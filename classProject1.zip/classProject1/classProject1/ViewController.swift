//
//  ViewController.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/30/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var reqImage: UIImageView!
    @IBOutlet weak var nearestImage: UIImageView!
    @IBOutlet weak var road: UIImageView!
    @IBOutlet weak var logo: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        nearestImage.image = UIImage(named: "icons8-map-64.png")
        reqImage.image = UIImage(named: "icons8-order-history-64.png")
        logo.image = UIImage(named: "icons8-car-64.png")
        road.image = UIImage(named: "road.jpg")
    }


}

