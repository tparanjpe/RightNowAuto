//
//  request.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import Foundation
import CoreData

class requests{
    var requests:[request] = []
    
    init(){}
    func addRequest(bName:String?, date:Date?, issue:String?, issueImage:NSData?, location:String?, urgency:Bool){
        let newReq = request(bName: bName, date: date, issue: issue, issueImage: issueImage, loc: location, urg: urgency)
        self.requests.append(newReq)
    }
    
    /*
    let managedObjectContext:NSManagedObjectContext?
    
    init(context: NSManagedObjectContext)
    {
        managedObjectContext = context
        
        // Getting a handler to the coredata managed object context
    }
    
    func saveContext(u:Bool, i:String, loc :String, bName: String){
        let ent = NSEntityDescription.entity(forEntityName: "Request", in: self.managedObjectContext!)
        
        let request = Request(entity: ent!, insertInto: managedObjectContext)
        request.buisnessName = bName
        request.date = Date()
        request.issue = i
        request.issueImage = nil
        request.location = loc
        request.urgency = u
        
        do {
            try managedObjectContext!.save()
            print("Contact Saved")
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
 */
}

class request{
    var bName:String?
    var date:Date?
    var issue:String?
    var issueImage:NSData?
    var loc:String?
    var urg:Bool
    
    init(bName:String?, date:Date?, issue:String?, issueImage:NSData?, loc:String?, urg:Bool){
        self.bName = bName
        self.date = date
        self.issue = issue
        self.issueImage = issueImage
        self.loc = loc
        self.urg = urg
    }
    
}
