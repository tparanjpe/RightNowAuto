//
//  DetailViewController.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit
import MapKit

class DetailViewController: UIViewController {
    var prob:String?
    var location:String?
    var reqdate:String?
    var biz:String?
    var pic:NSData?
    var urgency:Bool?
    var lat:Double?
    var long:Double?

    @IBAction func rating(_ sender: Any) {
    }
    @IBOutlet weak var myUrgency: UILabel!
    @IBOutlet weak var projImg: UIImageView!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var problem: UILabel!
    @IBOutlet weak var loc: UILabel!
    @IBOutlet weak var reqDate: UILabel!
    @IBOutlet weak var business: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        business.text = biz
        problem.text = prob
        loc.text = location
        if (urgency!){
            myUrgency.text = "High"
        }
        else{
            myUrgency.text = "Low"
        }
        reqDate.text = reqdate
        if let val = pic{
            if let myImage = UIImage(data: ((val as Data))){
                projImg.image = myImage
            }
        }
        enableMap()
        
        
        // Do any additional setup after loading the view.
    }
    func enableMap(){
        var place = loc.text
        
        let group = DispatchGroup()
        let queue = DispatchQueue.global()
        group.enter()
        DispatchQueue.main.async{
            let geoCoder = CLGeocoder();
            CLGeocoder().geocodeAddressString(place!, completionHandler:{(placemarks, error) in
                    if error != nil {
                        print("Geocode failed: \(error!.localizedDescription)")
                    } else if placemarks!.count > 0 {
                        let placemark = placemarks![0]
                        let location = placemark.location
                        let coords = location!.coordinate
                        self.lat = coords.latitude
                        self.long = coords.longitude
                        var myLoc = CLLocationCoordinate2D(
                            latitude: self.lat!, longitude: self.long!
                        )
                        
                        let span = MKCoordinateSpan.init(latitudeDelta: 0.05, longitudeDelta: 0.05)
                        let region = MKCoordinateRegion(center: myLoc, span: span)
                        self.map.setRegion(region, animated: true)
                        let ani = MKPointAnnotation()
                        ani.coordinate.latitude = self.lat!
                        ani.coordinate.longitude = self.long!
                        ani.title = place

                        self.map.addAnnotation(ani)
                        group.leave()
                }
            })
        }
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
