//
//  MapViewController.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/30/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController {
    
    var lat:Double?
    var long:Double?

    @IBOutlet weak var myMap: MKMapView!
    @IBOutlet weak var helpPlace: UITextField!
    @IBOutlet weak var helpTopic: UITextField!
    @IBOutlet weak var image: UIImageView!
    @IBAction func goButton(_ sender: Any) {
        enableMap()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        image.image = UIImage(named: "icons8-garage-64.png")

        // Do any additional setup after loading the view.
    }
    
    func enableMap(){
        var place = helpPlace.text
        var searchCriteria = helpTopic.text
        let group = DispatchGroup()
        let queue = DispatchQueue.global()
        group.enter()
        DispatchQueue.main.async{
            let geoCoder = CLGeocoder();
            CLGeocoder().geocodeAddressString(place!, completionHandler:{(placemarks, error) in
                    if error != nil {
                        print("Geocode failed: \(error!.localizedDescription)")
                    } else if placemarks!.count > 0 {
                        let placemark = placemarks![0]
                        let location = placemark.location
                        let coords = location!.coordinate
                        self.lat = coords.latitude
                        self.long = coords.longitude
                        
                        group.leave()
                }
            })
        }
        group.notify(queue: .main){
            queue.async{
                let whitespace = NSCharacterSet.whitespaces
                let spaceIndex = searchCriteria?.rangeOfCharacter(from: whitespace)
                //not nil means there is a whitespace
                //if theres a space, it replaces it with an underscore for api call
                if (spaceIndex != nil){
                    var newString = searchCriteria?.replacingOccurrences(of: " ", with: "_")
                    searchCriteria = newString
                }
                let apikey = "7cHk72_D8n9EIUIiGYlpNIRI6O8xSEfM2jh0ltsh7h9IQhONr1Ze__KQAIgR_rhtzUINUgIi4xIKFSTzBrrpv9mE534FGV09r9i_qYUbPoZu4IlMUElERO83Up2pX3Yx"
                
                let urlAsString = "https://api.yelp.com/v3/businesses/search?term=\(searchCriteria!)&latitude=\(self.lat!)&longitude=\(self.long!)"
                print(urlAsString)
                let url = URL(string: urlAsString)!
                var request = URLRequest(url:url)
                request.setValue("Bearer \(apikey)", forHTTPHeaderField: "Authorization")
                request.httpMethod = "GET"
                print("Out here")
                URLSession.shared.dataTask(with: request){(data, response, error) in
                    if let error = error{
                        print("In here")
                        print(error.localizedDescription)
                    }
                    do{
                        print("In there")
                        let jsonResult = (try! JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers)) as! NSDictionary
                        print(jsonResult)
                        //clear the map for the next call
                        self.myMap.removeAnnotations(self.myMap.annotations)
                        let setOne = jsonResult["businesses"]! as! NSArray
                        var times:Int = 0
                        if setOne.count > 6{
                            times = 5
                        }
                        else{
                            times = setOne.count - 1
                        }
                        for val in 0...times{
                            let y = setOne[val] as? [String: AnyObject]
                            let mapLong: Double = (y!["coordinates"]!["longitude"]) as! Double
                            let mapLat: Double = (y!["coordinates"]!["latitude"]) as! Double
                            let mapName: String = (y!["name"]) as! String
                            let mapPhone: String = (y!["phone"]) as! String
                            
                            var location = CLLocationCoordinate2D(
                                latitude: self.lat!, longitude: self.long!
                            )
                            
                            let span = MKCoordinateSpan.init(latitudeDelta: 0.05, longitudeDelta: 0.05)
                            let region = MKCoordinateRegion(center: location, span: span)
                            self.myMap.setRegion(region, animated: true)
                            let ani = MKPointAnnotation()
                            ani.coordinate.latitude = mapLat
                            ani.coordinate.longitude = mapLong
                            ani.title = mapName
                            ani.subtitle = String(mapPhone)

                            self.myMap.addAnnotation(ani)
                        }
                        
                    }
                    catch{
                        print("Caught error")
                    }
                    
                }.resume()
            }
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
