//
//  HistoryTableViewController.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit
import CoreData

class HistoryTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var myTable: UITableView!
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var myReqModel:requests = requests()
    var fetchedResults = [Request]()
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchCoreDataEntities()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    func fetchCoreDataEntities(){
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Request")
        fetchedResults = ((try? managedObjectContext.fetch(fetchRequest)) as? [Request])!
        //print(fetchedResults)
        for entity in fetchedResults{
            //print(entity.date, "\nNext:\n")
            myReqModel.addRequest(bName: entity.buisnessName, date: entity.date, issue: entity.issue, issueImage: entity.issueImage, location: entity.location, urgency: entity.urgency)
        }
        
        self.myTable.reloadData()

    }
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return fetchedResults.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Request")
        fetchedResults = ((try? managedObjectContext.fetch(fetchRequest)) as? [Request])!
        print(fetchedResults)
        let cell = tableView.dequeueReusableCell(withIdentifier: "reqCell", for: indexPath) as! ReqTableViewCell
        cell.dateName.text = fetchedResults[indexPath.row].buisnessName

        // Configure the cell...

        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if (segue.identifier == "toHistoryDetail"){
            if let viewController:DetailViewController = segue.destination as? DetailViewController{
                let selectedIndex: IndexPath = self.myTable.indexPath(for: sender as! UITableViewCell)!
                let obj = fetchedResults[selectedIndex.row]
                print(obj.buisnessName)
                viewController.biz = obj.buisnessName
                viewController.urgency = obj.urgency
                viewController.location = obj.location
                viewController.prob = obj.issue
                viewController.pic = obj.issueImage
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let str = dateFormatter.string(from: obj.date!)
                viewController.reqdate = str

                
            }
        }

        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
