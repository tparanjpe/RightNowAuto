//
//  ReqTableViewCell.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit

class ReqTableViewCell: UITableViewCell {

    @IBOutlet weak var dateName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
