//
//  Request+CoreDataProperties.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//
//

import Foundation
import CoreData


public class Request: NSManagedObject{

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Request> {
        return NSFetchRequest<Request>(entityName: "Request")
    }

    @NSManaged public var urgency: Bool
    @NSManaged public var issue: String?
    @NSManaged public var date: Date?
    @NSManaged public var location: String?
    @NSManaged public var buisnessName: String?
    @NSManaged public var issueImage: NSData?
    
    func set(urg:Bool, iss:String?, date:Date?, loc:String?, bName:String?, issImg: NSData?){
        self.urgency = urg
        self.issue = iss
        self.date = date
        self.location = loc
        self.buisnessName = bName
        self.issueImage = issImg
    }

}
