//
//  RequestViewController.swift
//  classProject1
//
//  Created by Tara Paranjpe (Student) on 10/31/20.
//  Copyright © 2020 Tara Paranjpe (Student). All rights reserved.
//

import UIKit
import CoreData
import CoreLocation

class RequestViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CLLocationManagerDelegate {
    var myLocManager = CLLocationManager()
    var myReqModel:requests = requests()
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var req:requests?
    let picker = UIImagePickerController()
    var fetchedResults = [Request]()
    var myImage:NSData?
    var currentLat:Double?
    var currentLong:Double?


    @IBOutlet weak var bName: UITextField!
    @IBOutlet weak var issue: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var tools: UIImageView!
    @IBOutlet weak var urgency: UISwitch!
    @IBOutlet weak var pageImg: UIImageView!
    @IBAction func submit(_ sender: Any) {
        if (bName.text == "" || issue.text == "" || address.text == ""){
            let alert = UIAlertController(title: "Please fill out all fields before submitting!", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok!", style: .cancel, handler: nil))
            self.present(alert, animated: true)

        }
        else{
            self.myReqModel.addRequest(bName: bName.text!, date: Date(), issue: issue.text!, issueImage: nil, location: address.text!, urgency: urgency.isOn)
            let ent = NSEntityDescription.entity(forEntityName: "Request", in: self.managedObjectContext)
            
            let newItem = Request(entity: ent!, insertInto: self.managedObjectContext)
            
            newItem.set(urg: urgency.isOn, iss: issue.text!, date: Date(), loc: address.text!, bName: bName.text!, issImg: myImage)
            
            do {
                try self.managedObjectContext.save()
                print(self.managedObjectContext)
                print("contact saved!")
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Request")
                let fetchedResults = ((try? managedObjectContext.fetch(fetchRequest)) as? [Request])!
                let alert = UIAlertController(title: "Request Submitted!", message: nil, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok!", style: .cancel, handler: nil))
                self.present(alert, animated: true)

                //print(fetchedResults)
            } catch _ {
                let alert = UIAlertController(title: "Error Submitting Request", message: nil, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Retry", style: .cancel, handler: nil))
                print("error in saving")
            }
        }
        
        
    }
    
    @IBAction func getLocation(_ sender: Any) {
        
        if (currentLong == nil || currentLat == nil){
            print("cannot get current location")
        }
        else{
            let location = CLLocation(latitude: self.currentLat!, longitude: self.currentLong!)
            let geoCoder = CLGeocoder()
            geoCoder.reverseGeocodeLocation(location, completionHandler: {(placemarks, error) in
                if error == nil{
                    let currLocation = placemarks! as [CLPlacemark]
                    if (currLocation.count > 0){
                        let myLocation = placemarks![0]
                        self.address.text = "\(myLocation.locality!), \(myLocation.administrativeArea!)"
                    }
                    //completionHandler(currLocation)
                    //self.address.text = currLocation as! String
                }
                
                
                
            })
        }
        
    
    }
    @IBAction func addImgCR(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
        self.picker.allowsEditing = false
        self.picker.sourceType = .photoLibrary
        self.picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        self.picker.modalPresentationStyle = .popover
        self.present(self.picker, animated: true, completion: nil)
        
        }
    }
    
    @IBAction func addImgCamera(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
               self.picker.allowsEditing = false
               self.picker.sourceType = UIImagePickerController.SourceType.camera
               self.picker.cameraCaptureMode = .photo
               self.picker.modalPresentationStyle = .fullScreen
               self.present(self.picker, animated: true,completion: nil)
           } else {
               print("No camera")
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        print("hello!")
        picker .dismiss(animated: true, completion: nil)
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Request")
        fetchedResults = ((try? managedObjectContext.fetch(fetchRequest)) as? [Request])!
        print(fetchedResults)
        var otherImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        myImage = (otherImage.pngData()!) as NSData
        
        // fetch resultset has the recently added row without the image
        // this code ad the image to the row
        /*
        if let c = fetchedResults.last, let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            c.issueImage = image.pngData()! as NSData
            
            //update the row with image
            print("picture saved")
            //print(IndexPath))
            //myTable.reloadRows(at: [indexPath], with: .automatic)

            //updateLastRow()
            print("exiting")

            do {
                try managedObjectContext.save()
            } catch {
                print("Error while saving the new image")
            }
            
        }
 */
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self

        tools.image = UIImage(named: "tool.jpg")
        pageImg.image = UIImage(named:"location.png")
        myLocManager.delegate = self
        myLocManager.requestWhenInUseAuthorization()
        myLocManager.desiredAccuracy = kCLLocationAccuracyBest
        myLocManager.requestWhenInUseAuthorization()
        myLocManager.startUpdatingLocation()
       
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    class func isLocationServiceEnabled() -> Bool {
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
            case .notDetermined, .restricted, .denied:
                return false
            case .authorizedAlways, .authorizedWhenInUse:
                return true
            default:
                print("Something wrong with Location services")
                return false
            }
        } else {
            print("Location services are not enabled")
            return false
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        print(locations)
        
        //userLocation - there is no need for casting, because we are now using CLLocation object

        let userLocation:CLLocation = locations[0]
        self.currentLat = userLocation.coordinate.latitude
        self.currentLong = userLocation.coordinate.longitude
        
        print("\(userLocation.coordinate.latitude)")
        
        print("\(userLocation.coordinate.longitude)")
            
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }

}
